uci set monlor.tinyproxy=config
uci set monlor.tinyproxy.enable=0
