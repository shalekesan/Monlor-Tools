uci set monlor.kodexplorer=config
uci set monlor.kodexplorer.enable=0
