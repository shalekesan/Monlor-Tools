#!/bin/ash
#copyright by monlor
source /etc/monlor/scripts/base.sh
/etc/monlor/scripts/init.sh
#检查重启服务
