#!/bin/ash
#copyright by monlor
source /etc/monlor/scripts/base.sh

#检查重启服务