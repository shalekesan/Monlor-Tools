uci set monlor.vsftpd=config
uci set monlor.vsftpd.enable=0
