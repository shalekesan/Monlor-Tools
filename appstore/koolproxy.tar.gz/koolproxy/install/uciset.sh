uci set monlor.koolproxy=config
uci set monlor.koolproxy.enable=0
