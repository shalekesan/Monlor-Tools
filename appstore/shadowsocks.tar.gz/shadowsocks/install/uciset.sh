uci set monlor.shadowsocks=config
uci set monlor.shadowsocks.enable=0
