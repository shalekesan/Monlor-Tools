uci set monlor.kms=config
uci set monlor.kms.enable=0
