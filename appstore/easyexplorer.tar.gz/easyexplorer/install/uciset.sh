uci set monlor.easyexplorer=config
uci set monlor.easyexplorer.enable=0
